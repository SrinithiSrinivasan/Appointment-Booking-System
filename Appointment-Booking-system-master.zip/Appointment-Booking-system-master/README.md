APPOINTMENT BOOKING SYSTEM

MODULES DESCRIPTION

2.1 Signup Module
When a user opens the application for the first time , he/she is required to sign up by filling in their details like name,email id as present in the university database then other information like department and password. 

2.2 Login Module
This module allows a user to log in to his account by specifying the username and password.

2.3 Student Module
This module is designed for the student community.Students can view their profile details    and carry out certain other functions. It consists of the following sub-modules .

 2.3.1 Make an appointment 
A student can place a request for an appointment to any lecturer specifying the purpose and the date and time of the appointment that he needs using this module.

 2.3.2 Upcoming appointments and cancellation of appointments 
The list of all appointments that are confirmed are displayed in a table . Also the facility to request for an cancellation of  an appointment 2 hours prior to its scheduled time is possible in this module .

 2.3.3 Feedback Module 
Once an appointment is completed,the student can fill a feedback form describing how useful the appointment with the teacher was.

 2.3.4 Change password Module
The students are also provided with the facility of changing the password that was set previously.

2.4 Staff Module
Similar to the student module,this module is designed for the teacher community. It displays the profile of a teacher. Also includes certain other functionalities.

 2.4.1 Approval/Rejection of Appointments 
 When the student places request for a appointment , the staff can approve or reject it depending on their availability .

 2.4.2 Appointment history with feedback
 Similar to the History of appointment in the student’s module,even the teacher can view their history of appointments . It is   displayed in a table format  specifying all details about the appointment along with the feedback from the students.

 2.4.3 Customized schedule 
 The teacher is allowed to update his/her from and to dates of unavailability in case they are going on a vacation or if would not be available due to some situations.The students will be prevented from requesting for a appointment on the specified dates .

 2.4.4 Cancellation of Appointments
 The teacher is allowed to cancel the approved appointment anytime.

